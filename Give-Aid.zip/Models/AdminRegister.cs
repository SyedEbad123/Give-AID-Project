﻿using System.ComponentModel.DataAnnotations;

namespace Give_Aid.Models
{
    public class AdminRegister
    {
        [Key]
        public int a_id { get; set; }
        [Required]
        public string a_name { get; set; }
        [Required]
        public string a_email { get; set; }
        [Required]
        public string a_pass { get; set; }
        [Required]
        public string a_image { get; set; }
    }
}
