﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Win32;

namespace Give_Aid.Models
{
    public class mydb : DbContext
    {
        public mydb(DbContextOptions<mydb> options) : base(options) { }
        public DbSet<AdminRegister> a_register { get; set; }
        public DbSet<Ngo> Ngos { get; set; }
        public DbSet<Cause> Causes { get; set; }
        public DbSet<UserRegister> u_register { get; set; }
        public DbSet<Contact> contact { get; set; }
        public DbSet<Contact> gallery { get; set; }
        public DbSet<Donation> donations  { get; set; }
    }
}
