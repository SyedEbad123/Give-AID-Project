﻿using System.ComponentModel.DataAnnotations;

namespace Give_Aid.Models
{
    public class UserRegister
    {
        [Key]
        public int user_id { get; set; }
        [Required]
        public string user_name { get; set; }
        [Required]
        public string user_email { get; set; }
        [Required]
        public string user_password { get; set; }
        [Required]
        public int user_phone { get; set; }
        
    }
}
