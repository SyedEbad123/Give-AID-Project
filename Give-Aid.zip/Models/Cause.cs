﻿using System.ComponentModel.DataAnnotations;

namespace Give_Aid.Models
{
    public class Cause
    {
        [Key]
        public int cause_id { get; set; }
        [Required]
        public string cause_name { get; set; }
        [Required]
        public string cause_desc { get; set; }

        public ICollection<Donation> donations_table { get; set; }
    }
}
