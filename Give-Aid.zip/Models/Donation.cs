﻿using Give_Aid.Migrations;
using System.ComponentModel.DataAnnotations;

namespace Give_Aid.Models
{
    public class Donation
    {
        [Key]
        public int d_id { get; set; }
        [Required]
        public string d_name { get; set; }
        [Required]
        public string d_email { get; set;}
        [Required]
        public string d_amount { get; set; }
        [Required]
        public string d_address { get; set; }
        [Required]
        public string d_zipcode { get; set; }
        [Required]
        public string d_city { get; set; }
        [Required]
        public string d_cardnumber { get; set; }
        [Required]
        public string d_expiry { get; set; }
        [Required]
        public string d_cvc { get; set; }

        public int causeid { get; set; }
        public Cause causes { get; set; }


    }
}
