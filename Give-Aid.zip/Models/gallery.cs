﻿using System.ComponentModel.DataAnnotations;

namespace Give_Aid.Models
{
    public class gallery
    {
        [Key]
        public int gallery_Id { get; set; }
        [Required]
        public string gallery_image { get; set; }
    }
}
