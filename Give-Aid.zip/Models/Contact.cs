﻿using System.ComponentModel.DataAnnotations;

namespace Give_Aid.Models
{
    public class Contact
    {
        [Key]
        public int contact_Id { get; set; }
        [Required]
        public int contact_phone { get; set; }
        [Required]
        public string contact_email { get; set; }
        [Required]
        public string contact_address { get; set; }
    }
}
