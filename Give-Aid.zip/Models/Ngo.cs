﻿using System.ComponentModel.DataAnnotations;

namespace Give_Aid.Models
{
    public class Ngo
    {
        [Key]
        public int ngo_Id { get; set; }
        [Required]
        public string ngo_image { get; set; }
        [Required]
        public string ngo_name { get; set; }
        [Required]
        public string ngo_desc { get; set; }

    }
}
