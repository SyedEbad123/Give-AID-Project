﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Give_Aid.Models;

namespace Give_Aid.Controllers
{
    public class NgoController : Controller
    {
        private readonly mydb _context;
        private readonly IWebHostEnvironment env;

        public NgoController(mydb context, IWebHostEnvironment env)
        {
            _context = context;
            this.env = env;
        }

        // GET: Ngo
        public async Task<IActionResult> Index()
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToAction("login");
            }
            return _context.Ngos != null ? 
                          View(await _context.Ngos.ToListAsync()) :
                          Problem("Entity set 'mydb.Ngos'  is null.");
        }

        // GET: Ngo/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToAction("login");
            }
            if (id == null || _context.Ngos == null)
            {
                return NotFound();
            }

            var ngo = await _context.Ngos
                .FirstOrDefaultAsync(m => m.ngo_Id == id);
            if (ngo == null)
            {
                return NotFound();
            }

            return View(ngo);
        }

        // GET: Ngo/Create
        public IActionResult Create()
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToAction("login");
            }
            return View();
        }

        // POST: Ngo/Create
        [HttpPost]
        public async Task<IActionResult> Create([Bind("ngo_Id,ngo_image,ngo_name,ngo_desc")] Ngo ngo, IFormFile ngo_image)
        {
            string ngoimg = Path.Combine(env.WebRootPath, "NGO", Path.GetFileName(ngo_image.FileName));
            ngo_image.CopyTo(new FileStream(ngoimg, FileMode.Create));
            ngo.ngo_image = ngo_image.FileName;

            _context.Add(ngo);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            
           
        }

        // GET: Ngo/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToAction("login");
            }
            if (id == null || _context.Ngos == null)
            {
                return NotFound();
            }

            var ngo = await _context.Ngos.FindAsync(id);
            if (ngo == null)
            {
                return NotFound();
            }
            return View(ngo);
        }

        // POST: Ngo/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        public async Task<IActionResult> Edit(int id, [Bind("ngo_Id,ngo_image,ngo_name,ngo_desc")] Ngo ngo)
        {
            if (id != ngo.ngo_Id)
            {
                return NotFound();
            }

            
                try
                {

                _context.Update(ngo);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!NgoExists(ngo.ngo_Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
          
        }

        // GET: Ngo/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToAction("login");
            }
            if (id == null || _context.Ngos == null)
            {
                return NotFound();
            }

            var ngo = await _context.Ngos
                .FirstOrDefaultAsync(m => m.ngo_Id == id);
            if (ngo == null)
            {
                return NotFound();
            }

            return View(ngo);
        }

        // POST: Ngo/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Ngos == null)
            {   
                return Problem("Entity set 'mydb.Ngos'  is null.");
            }
            var ngo = await _context.Ngos.FindAsync(id);
            if (ngo != null)
            {
                _context.Ngos.Remove(ngo);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool NgoExists(int id)
        {
          return (_context.Ngos?.Any(e => e.ngo_Id == id)).GetValueOrDefault();
        }
    }
}
