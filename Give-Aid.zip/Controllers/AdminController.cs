﻿

using Give_Aid.Migrations;
using Give_Aid.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Win32;
using System.Runtime.InteropServices;

namespace Give_Aid.Controllers
{
    public class AdminController : Controller
    {
        private readonly mydb db;
        private readonly IWebHostEnvironment env;
        public AdminController(mydb db, IWebHostEnvironment _env)
        {
            this.db = db;
            this.env = _env;
        }
        public IActionResult Index()
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToAction("login");
            }
            var c=db.Causes.ToList();
            var n = db.Ngos.ToList();
            var u = db.u_register.ToList();
            var d = db.donations.ToList();
            decimal totalDonationAmount = d.Sum(donation => Convert.ToDecimal(donation.d_amount));

            var data = new
            {
                Causes = c,
                CauseCount = c.Count,
                Ngos = n,
                NgoCount = n.Count,
                Users = u,
                UserCount = u.Count,
                Donos = d,
                TotalDonationAmount = totalDonationAmount
            };

            return View(data);
        }
        
        [HttpPost]
        public IActionResult login(AdminRegister al)
        {
            var check = db.a_register.Where(a => a.a_email == al.a_email && a.a_pass == al.a_pass).FirstOrDefault();
            if (check != null)
            {
                HttpContext.Session.SetString("username", check.a_name);
                HttpContext.Session.SetString("image", check.a_image);
                HttpContext.Session.SetString("email", check.a_email);
                HttpContext.Session.SetInt32("userId", check.a_id);

                return RedirectToAction("Index");
            }
            else
            {
                ViewBag.msg = "not";
            }
            return View();
        }
        [HttpPost]
        public IActionResult register(AdminRegister ar, IFormFile a_image) { 

            string aimg=Path.Combine(env.WebRootPath, "uploads", Path.GetFileName(a_image.FileName));
            a_image.CopyTo(new FileStream(aimg, FileMode.Create));
            ar.a_image=a_image.FileName;
        
            db.a_register.Add(ar);
            db.SaveChanges();
            return RedirectToAction("login");
        }
        public IActionResult register()
        {
            return View();
        }
        public IActionResult login()
        {
            return View();
        }
        public IActionResult logout()
        {
            HttpContext.Session.Remove("username");
            return RedirectToAction("login");
        }
        public IActionResult showUser()
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToAction("login", "Admin");
            }
            var su = db.u_register.ToList();
            return View(su);
        }
        public IActionResult deleteUser(int id) { 
        var du = db.u_register.Find(id);
            db.u_register.Remove(du);
            db.SaveChanges();
            return RedirectToAction("showUser");
        }
        public IActionResult editUser(int id)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToAction("login", "Admin");
            }
            var eu = db.u_register.Find(id);
            return View(eu);
        }
       [HttpPost]
       public IActionResult editUser(UserRegister u,int id)
       {
            var eu = db.u_register.Find(id);
            eu.user_name = u.user_name;
            eu.user_email = u.user_email;
            eu.user_password = u.user_password;
            eu.user_phone = u.user_phone;
            db.SaveChanges();
           return RedirectToAction("showUser");
        }
        public IActionResult editAdmin(int id)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToAction("login", "Admin");
            }
            var ea = db.a_register.Find(id);
            return View(ea);
        }
        [HttpPost]
        public IActionResult editAdmin(AdminRegister ar, int id)
        {
            var a = db.a_register.Find(id);
            a.a_name = ar.a_name;
            a.a_email = ar.a_email;
            a.a_pass = ar.a_pass;
            db.SaveChanges();
            HttpContext.Session.Remove("username");
            return RedirectToAction("login");
        }

        public IActionResult donations()
        {
            var dono = db.donations.ToList();
            return View(dono);
        }

    }
}
