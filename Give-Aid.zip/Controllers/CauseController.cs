﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Give_Aid.Models;

namespace Give_Aid.Controllers
{
    public class CauseController : Controller
    {
        private readonly mydb _context;

        public CauseController(mydb context)
        {
            _context = context;
        }

        // GET: Cause
        public async Task<IActionResult> Index()
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToAction("login", "Admin");
            }
            return _context.Causes != null ? 
                          View(await _context.Causes.ToListAsync()) :
                          Problem("Entity set 'mydb.Causes'  is null.");
        }

        // GET: Cause/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToAction("login", "Admin");
            }
            if (id == null || _context.Causes == null)
            {
                return NotFound();
            }

            var cause = await _context.Causes
                .FirstOrDefaultAsync(m => m.cause_id == id);
            if (cause == null)
            {
                return NotFound();
            }

            return View(cause);
        }

        // GET: Cause/Create
        public IActionResult Create()
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToAction("login", "Admin");
            }
            return View();
        }

        // POST: Cause/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("cause_id,cause_name,cause_desc")] Cause cause)
        {
            
                _context.Add(cause);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            return View(cause);
        }

        // GET: Cause/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToAction("login", "Admin");
            }
            if (id == null || _context.Causes == null)
            {
                return NotFound();
            }

            var cause = await _context.Causes.FindAsync(id);
            if (cause == null)
            {
                return NotFound();
            }
            return View(cause);
        }

        // POST: Cause/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("cause_id,cause_name,cause_desc")] Cause cause)
        {
            if (id != cause.cause_id)
            {
                return NotFound();
            }

           
                try
                {
                    _context.Update(cause);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CauseExists(cause.cause_id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                
                /*return RedirectToAction(nameof(Index));*/
            }
            return View(cause);
        }

        // GET: Cause/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToAction("login", "Admin");
            }
            if (id == null || _context.Causes == null)
            {
                return NotFound();
            }

            var cause = await _context.Causes
                .FirstOrDefaultAsync(m => m.cause_id == id);
            if (cause == null)
            {
                return NotFound();
            }

            return View(cause);
        }

        // POST: Cause/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Causes == null)
            {
                return Problem("Entity set 'mydb.Causes'  is null.");
            }
            var cause = await _context.Causes.FindAsync(id);
            if (cause != null)
            {
                _context.Causes.Remove(cause);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CauseExists(int id)
        {
          return (_context.Causes?.Any(e => e.cause_id == id)).GetValueOrDefault();
        }
    }
}
