﻿using Give_Aid.Migrations;
using Give_Aid.Models;
using Microsoft.AspNetCore.Mvc;

namespace Give_Aid.Controllers
{
    public class ContactController : Controller
    {
        private readonly mydb _contact;
        public ContactController(mydb contact)
        {
            this._contact = contact;
        }
        public IActionResult Index()
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToAction("login", "Admin");
            }

            var contacts = _contact.contact.ToList(); // Assuming _contact is correctly initialized

            return View(contacts);
        }
        public IActionResult addContact()
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToAction("login", "Admin");
            }

            // Check if there's already a contact record in the database
            var existingContact = _contact.contact.FirstOrDefault();

            if (existingContact != null)
            {
                // A contact record already exists, redirect to Index
                return RedirectToAction("Index");
            }

            return View();
        }

        [HttpPost]
        public IActionResult addContact(Contact cc)
        {
            // Check if there's already a contact record in the database
            var existingContact = _contact.contact.FirstOrDefault();

            if (existingContact != null)
            {
                // A contact record already exists, redirect to Index
                return RedirectToAction("Index");
            }

            _contact.contact.Add(cc);
            _contact.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult editContact()
        {
            return View();
        }
        [HttpPost]
        public IActionResult editContact(Contact c,int Id)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToAction("login", "Admin");
            }
            var ec = _contact.contact.Find(Id);
            ec.contact_phone = c.contact_phone;
            ec.contact_email = c.contact_email;
            ec.contact_address = c.contact_address;
            _contact.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult deleteContact(int Id)
        {
            var dc = _contact.contact.Find(Id);
            _contact.contact.Remove(dc);
            _contact.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
