﻿using Give_Aid.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace Give_Aid.Controllers
{
    public class UserController : Controller
    {
        private readonly mydb _user;
        public UserController(mydb user) { 
        this._user = user;
        }
        public IActionResult Index()
        {

            var cu = _user.Causes.ToList();
            var nu = _user.Ngos.ToList();
            

            var data = new
            {
                Causes = cu,
                
                Ngos = nu,
               
                
            };

            return View(data);
        }
            public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(UserRegister ul)
        {
            var ucheck = _user.u_register.Where(u => u.user_email == ul.user_email && u.user_password == ul.user_password).FirstOrDefault();
            if (ucheck != null)
            {
                HttpContext.Session.SetString("u_username", ucheck.user_name);
                HttpContext.Session.SetString("u_email", ucheck.user_email);

                return RedirectToAction("Index", "User");
            }
            else
            {
                ViewBag.msg = "not";
            }
            return View();
        }
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Register(UserRegister ur)
        {
            _user.u_register.Add(ur);
            _user.SaveChanges();
            return RedirectToAction("Login", "User");
        }

        public IActionResult Gallery()
        {
            var gn = _user.Ngos.ToList();
            return View(gn);
        }
        public IActionResult contact()
        {
            var cc = _user.contact.ToList();
            return View(cc);
        }

        public IActionResult partner()
        {
            var partn = _user.Ngos.ToList();
            return View(partn);
        }

        public IActionResult Events()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        public IActionResult donate()
        {
            if (HttpContext.Session.GetString("u_username") == null)
            {
                return RedirectToAction("Login", "User");
            }
            ViewData["causeid"] = new SelectList(_user.Causes, "cause_id", "cause_name");
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> donate([Bind("d_id,d_name,d_email,d_amount,d_address,d_city,d_zipcode,d_cardnumber,d_expiry,d_cvc,causeid")] Donation D)
        {
            
                _user.donations.Add(D);
                _user.SaveChanges();
                return RedirectToAction("index", "User");
           
        }

    }
}
